import torch.nn as nn


class LinearRegressionModel(nn.Module):
    def __init__(self, n_input):
        super(LinearRegressionModel, self).__init__()
        self.mcpt = nn.Sequential(
            nn.Linear(n_input, 50),
            nn.ReLU(),
            nn.Linear(50, 1)
        )

    def forward(self, x):
        result = self.mcpt(x)
        return result

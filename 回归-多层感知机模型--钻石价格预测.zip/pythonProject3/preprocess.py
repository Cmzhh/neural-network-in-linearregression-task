import pandas as pd
import sklearn
from sklearn import preprocessing

def pre():
    df = pd.read_csv("d:/dataset/archive/diamonds.csv", index_col=0)
    y = df["price"]
    num = len(df)
    color_dic = {"D": 1, "E": 2, "F": 3, "G": 4, "H": 5, "I": 6, "J": 7}
    cut_dic = {"Ideal": 1, "Premium": 2, "Very Good": 3, "Good": 4, "Fair": 5}
    clarity_dic = {"IF": 1, 'VVS1': 2, 'VVS2': 3, 'VS1': 4, 'VS2': 5, 'SI1': 6,
               'SI2': 7, 'I1': 8}
    df["color"] = df["color"].map(color_dic)
    df["cut"] = df["cut"].map(cut_dic)
    df["clarity"] = df["clarity"].map(clarity_dic)
    X = df.drop("price", axis=1)
    print(len(X))
    X = pd.DataFrame(preprocessing.scale(X))
    print(len(X))
    n_1 = int(0.6 * num)
    n_2 = int(0.8 * num)
    X_train = X[:n_1]
    X_val = X[n_1: n_2]
    X_test = X[n_2:]
    y_train = y[:n_1]
    y_val = y[n_1: n_2]
    y_test = y[n_2:]
    y_train.to_csv("d:/dataset/archive/train_lbl.csv", index=False)
    X_train.to_csv("d:/dataset/archive/train_x.csv", index=False)
    y_val.to_csv("d:/dataset/archive/val_lbl.csv", index=False)
    X_val.to_csv("d:/dataset/archive/val_x.csv", index=False)
    y_test.to_csv("d:/dataset/archive/test_lbl.csv", index=False)
    X_test.to_csv("d:/dataset/archive/test_x.csv", index=False)


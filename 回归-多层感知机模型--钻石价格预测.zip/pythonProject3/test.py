from torch.utils.data import DataLoader
from mydataset import DiaDataset
from model import LinearRegressionModel
import torch

test_x_path = "d:/dataset/archive/test_x.csv"
test_lbl_path = "d:/dataset/archive/test_lbl.csv"

test_dataset = DiaDataset(test_x_path, test_lbl_path)
test_dataloader = DataLoader(test_dataset, batch_size=1, shuffle=True)

mtp = LinearRegressionModel(9)
mtp.load_state_dict(torch.load("model_weights.pth"))

i = 0
for X, y in test_dataloader:
    pred = mtp(X)
    print(f"\n prediction = {pred} y = {y}")
    i += 1
    if i > 20:
        break

import torch
from torch.utils.data import Dataset
import preprocess
import torch.utils.data.dataloader
import pandas as pd
from  pandas import Series


class DiaDataset(Dataset):
    def __init__(self, X_path, label_path, transform=None, target_transform=None):
        # preprocess.pre()
        self.X = pd.read_csv(X_path)
        self.lbl = pd.read_csv(label_path)
        self.transform = transform
        self.target_transform = target_transform

    def __len__(self):
        return len(self.lbl)

    def __getitem__(self, idx):
        X = torch.FloatTensor(self.X.iloc[idx, :].values)
        y = float(self.lbl.iloc[idx, 0])
        if self.transform:
            X = self.transform(X)
        if self.target_transform:
            y = self.target_transform(y)

        return X, y

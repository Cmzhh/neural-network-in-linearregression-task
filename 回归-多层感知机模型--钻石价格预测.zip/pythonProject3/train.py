from torch.utils.data import DataLoader
import torch.functional as F
import torch.optim
from mydataset import DiaDataset
import model
import matplotlib.pyplot as plt

x_train_path = "d:/dataset/archive/train_x.csv"
lbl_train_path = "d:/dataset/archive/train_lbl.csv"
x_val_path = "d:/dataset/archive/val_x.csv"
lbl_val_path = "d:/dataset/archive/val_lbl.csv"
learning_rate = 1e-5
epoch = 100

loss_curve = []

training_data = DiaDataset(x_train_path, lbl_train_path)
val_data = DiaDataset(x_val_path, lbl_val_path)
train_DataLoader = DataLoader(training_data, batch_size=300, shuffle=True)
val_Data_Loader = DataLoader(val_data, batch_size=300, shuffle=True)

m_model = model.LinearRegressionModel(9)
loss_fn = torch.nn.MSELoss()
optimizer = torch.optim.SGD(m_model.parameters(), lr=learning_rate)


def main():
    minloss = 10000
    for i in range(epoch):
        print(f"This is Epoch {i + 1}\n___________________________")
        training_loop(train_DataLoader, m_model, loss_fn)
        loss_compare = val_loop(val_Data_Loader, m_model, loss_fn)
        if loss_compare < minloss:
            torch.save(m_model.state_dict(), "model_weights.pth")
            minloss = loss_compare
    print("All Done!")

    plt.plot(loss_curve, c='b', linewidth=1.5)
    plt.xlabel("epoch")
    plt.ylabel("loss")
    plt.title("learning curve")
    plt.show()


def training_loop(dataloader, model, loss_function):
    for batch, (X, y) in enumerate(dataloader):
        size = len(dataloader.dataset)
        pred = model(X)

        pred = pred.squeeze(1)
        loss = loss_function(pred.float(), y.float())

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        loss, current = loss.item(), batch * len(X)
        print(f"loss: {loss:>4f} [{current:>5d}/{size:>5d}]")


def val_loop(dataloader, model, loss_function):
    size = len(dataloader.dataset)
    val_loss = 0
    with torch.no_grad():
        for x, y in dataloader:
            pred = model(x)
            val_loss += loss_function(pred, y).item()
            print(f"pred_value: {pred} Y_value: {y}")

    val_loss /= size
    loss_curve.append(val_loss)
    print(f"val_loss:{val_loss}")
    return val_loss

if __name__ == '__main__':
    main()
